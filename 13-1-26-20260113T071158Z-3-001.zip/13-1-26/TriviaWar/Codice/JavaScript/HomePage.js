function startGame() {
  window.location.href = "../Html/ruota.html";
}
